create view 选课人数
as
select 课程.课程号,课程名,课程.教师号,姓名,院系,count(选课.课程号) as 选课人数
from 选课 right join 课程 on 选课.课程号=课程.课程号
	full join 教师 on 课程.教师号=教师.教师号
group by dbo.课程.课程号,课程名,课程.教师号,姓名,院系
GO
