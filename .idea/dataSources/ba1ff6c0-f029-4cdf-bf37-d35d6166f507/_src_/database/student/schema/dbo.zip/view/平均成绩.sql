create view 平均成绩
as
select 课程.课程号,课程名,课程.教师号,姓名,院系,avg(选课.成绩) as 平均成绩
from 选课 join 课程 on 选课.课程号=课程.课程号
	join 教师 on 课程.教师号=教师.教师号
group by 课程.课程号,课程名,课程.教师号,姓名,院系
GO
